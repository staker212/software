git init
git add .
git commit -m "Primer commit - estructura del proyecto"
git remote add origin https://github.com/tu_usuario/nombre_proyecto.git
git push -u origin main
